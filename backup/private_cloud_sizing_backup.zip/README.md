# Backup da Versão Estável

Este é um backup da versão estável do projeto Private Cloud Sizing, contendo todos os componentes e funcionalidades principais.

## Estrutura do Backup

```
backup/
├── App.tsx                    # Componente principal da aplicação
├── components/               # Pasta com todos os componentes
│   ├── ServerCalculator.tsx  # Calculadora de servidores físicos
│   ├── VirtualizationCalculator.tsx  # Calculadora de virtualização
│   ├── BackupCalculator.tsx  # Calculadora de backup
│   ├── StorageCalculator.tsx # Calculadora de armazenamento
│   ├── VsanCalculator.tsx    # Calculadora de vSAN
│   ├── Header.tsx           # Cabeçalho da aplicação
│   └── RackVisualization.tsx # Visualização do rack
└── README.md                # Este arquivo
```

## Funcionalidades Incluídas

1. Menu principal com:
   - Physical Servers
   - Virtualization
   - Storage
   - vSAN
   - Backup

2. Componentes:
   - Calculadora de servidores físicos
   - Calculadora de virtualização
   - Calculadora de backup
   - Calculadora de armazenamento
   - Calculadora de vSAN
   - Visualização do rack

3. Recursos:
   - Interface moderna com Tailwind CSS
   - Gráficos interativos
   - Exportação de relatórios
   - Visualização do rack em 3D

## Data do Backup

Este backup foi criado em 30/03/2024.

## Como Restaurar

Para restaurar esta versão:

1. Copie o conteúdo da pasta `backup` para a raiz do projeto
2. Substitua os arquivos existentes pelos arquivos do backup
3. Execute `npm install` para garantir que todas as dependências estejam instaladas
4. Execute `npm run dev` para iniciar o servidor de desenvolvimento 